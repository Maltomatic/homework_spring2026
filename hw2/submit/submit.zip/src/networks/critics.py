import itertools
from torch import nn
from torch.nn import functional as F
from torch import optim

import numpy as np
import torch
from torch import distributions

from infrastructure import pytorch_util as ptu

debug = False

class ValueCritic(nn.Module):
    """Value network, which takes an observation and outputs a value for that observation."""

    def __init__(
        self,
        ob_dim: int,
        n_layers: int,
        layer_size: int,
        learning_rate: float,
    ):
        super().__init__()

        self.network = ptu.build_mlp(
            input_size=ob_dim,
            output_size=1,
            n_layers=n_layers,
            size=layer_size,
        ).to(ptu.device)

        self.optimizer = optim.Adam(
            self.network.parameters(),
            learning_rate,
        )

    def forward(self, obs: torch.Tensor) -> torch.Tensor:
        # TODO(?V): implement the forward pass of the critic network
        ret = self.network(obs).squeeze(-1)
        if(debug):
            print(f"critic forward pass shape: {ret.shape} \n\tcritic forward pass: {ret}")
        return ret

    def update(self, obs: np.ndarray, q_values: np.ndarray) -> dict:
        obs = ptu.from_numpy(obs)
        q_values = ptu.from_numpy(q_values)

        # TODO(V): compute the loss using the observations and q_values
        pred = self.forward(obs)
        loss = F.mse_loss(pred, q_values)
        if(debug):
            print(f"critic update: pred shape: {pred.shape} \n\tpred: {pred} \n\tq_values shape: {q_values.shape} \n\tloss: {loss}")

        # TODO(V): perform an optimizer step
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        return {
            "Baseline Loss": loss.item(),
        }